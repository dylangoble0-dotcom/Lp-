# Contributing to Locust Protocol

See CONTRIBUTING guidelines in the repo. Run tests and follow branch naming conventions.

Local dev:
- Backend: cd locust-backend-full && npm ci && npm run dev
- Frontend: cd locust-frontend-full && npm ci && npm run dev
