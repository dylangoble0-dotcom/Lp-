# Locust Protocol - Backend

This repository contains the backend scaffold for Locust Protocol: multi-chain treasury/vault automation and token launch platform.

## Features
- Express API
- Prisma (Postgres)
- BullMQ job queue
- EVM & Solana payment listener skeletons
- Swap executor adapters (1inch / Jupiter placeholders)
- Keeper relayer skeleton
- Docker + docker-compose for local development

## Quick start (local)
1. Copy `.env.example` to `.env` and fill values.
2. `npm install`
3. Start services: `docker-compose up -d`
4. Run Prisma migrate:
   - `npx prisma generate`
   - `npx prisma migrate dev --name init`
5. Start dev server:
   - `npm run dev`

This repo is a scaffold. Review and complete swap adapters, relayer signing, and security before mainnet use.
