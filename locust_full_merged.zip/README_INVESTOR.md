# Locust Protocol — Investor Brief

Locust Protocol is a multi-chain token creation, treasury-backed liquidity, and automated launch infrastructure.

Key differentiators:
- Multi-chain token factory (EVM, Solana, Bitcoin)
- Treasury vaults and automation engine
- Non-custodial operations

Business model:
- Fees: token creation, vault creation, automation
- Subscriptions: analytics and premium features
- Enterprise: white-label and integration services

Contact: founder@example.com
