Locust Protocol Frontend (scaffold)

Run:
1. copy .env.local from .env.example and set NEXT_PUBLIC_SOLANA_RPC etc.
2. npm install
3. npm run dev

This scaffold includes Tailwind, RainbowKit (EVM wallet) and Solana wallet adapter integration.
It's a UI prototype; integrate with backend API endpoints for full functionality.
