import { Request, Response } from "express";
import { prisma } from "../../db/prismaClient";
import { logger } from "../../utils/logger";

export async function createVault(req: Request, res: Response) {
  try {
    const { ownerWallet, chain, address, tokenMint, thresholdUsd, config } = req.body;
    let user = await prisma.user.findUnique({ where: { wallet: ownerWallet }});
    if (!user) {
      user = await prisma.user.create({ data: { wallet: ownerWallet }});
    }
    const vault = await prisma.vault.create({
      data: {
        ownerId: user.id,
        chain,
        address,
        tokenMint,
        thresholdUsd: thresholdUsd ? parseFloat(thresholdUsd) : 0,
        config: config || {}
      }
    });
    res.json(vault);
  } catch (err) {
    logger.error("createVault error", err);
    res.status(500).json({ error: "internal" });
  }
}

export async function getVault(req: Request, res: Response) {
  const { vaultId } = req.params;
  const vault = await prisma.vault.findUnique({ where: { id: vaultId }, include: { operations: true }});
  res.json(vault);
}
