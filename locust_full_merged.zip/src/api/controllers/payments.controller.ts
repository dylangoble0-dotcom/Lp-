import { Request, Response } from "express";
import { logger } from "../../utils/logger";
import { prisma } from "../../db/prismaClient";
import { enqueuePaymentProcessing } from "../../workers/queue";

export async function handleEvmWebhook(req: Request, res: Response) {
  try {
    const payload = req.body;
    const p = await prisma.payment.create({
      data: {
        txHash: payload.txHash,
        chain: payload.chain,
        asset: payload.asset,
        amount: payload.amount,
        from: payload.from,
        to: payload.to
      }
    });
    await enqueuePaymentProcessing(p.id);
    res.json({ ok: true });
  } catch (err) {
    logger.error("evm webhook error", err);
    res.status(500).send("error");
  }
}

export async function handleSolWebhook(req: Request, res: Response) {
  try {
    const payload = req.body;
    const p = await prisma.payment.create({
      data: {
        txHash: payload.signature,
        chain: "solana",
        asset: payload.asset,
        amount: payload.amount,
        from: payload.from,
        to: payload.to
      }
    });
    await enqueuePaymentProcessing(p.id);
    res.json({ ok: true });
  } catch (err) {
    logger.error("sol webhook error", err);
    res.status(500).send("error");
  }
}
