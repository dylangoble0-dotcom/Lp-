import { Router } from "express";
import { createVault, getVault } from "../controllers/vaults.controller";

const router = Router();

router.post("/", createVault);
router.get("/:vaultId", getVault);

export default router;
