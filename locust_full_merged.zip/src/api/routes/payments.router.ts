import { Router } from "express";
import { handleEvmWebhook, handleSolWebhook } from "../controllers/payments.controller";

const router = Router();

router.post("/evm/webhook", handleEvmWebhook);
router.post("/solana/webhook", handleSolWebhook);

export default router;
