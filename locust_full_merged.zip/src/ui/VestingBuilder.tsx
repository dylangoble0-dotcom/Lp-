import React, { useState } from 'react';
import axios from 'axios';
export default function VestingBuilder() {
  const [beneficiary, setBeneficiary] = useState('');
  const [amount, setAmount] = useState('0');
  const [duration, setDuration] = useState('365');
  const [loading, setLoading] = useState(false);
  async function submit() {
    setLoading(true);
    try {
      const res = await axios.post('/api/vesting/create', { beneficiary, amount, duration });
      alert('Vesting created: ' + JSON.stringify(res.data));
    } catch (err) { alert('Error ' + String(err)); } finally { setLoading(false); }
  }
  return (
    <div className="card"><h3 className="text-lg font-medium">Vesting Schedule</h3>
    <label className="block mt-2">Beneficiary</label>
    <input className="w-full p-2 border rounded" value={beneficiary} onChange={e=>setBeneficiary(e.target.value)} />
    <label className="block mt-2">Amount</label>
    <input className="w-full p-2 border rounded" value={amount} onChange={e=>setAmount(e.target.value)} />
    <label className="block mt-2">Duration (days)</label>
    <input className="w-full p-2 border rounded" value={duration} onChange={e=>setDuration(e.target.value)} />
    <div className="mt-4"><button className="button" onClick={submit} disabled={loading}>{loading ? 'Creating...' : 'Create Vesting'}</button></div>
    </div>
  );
}
