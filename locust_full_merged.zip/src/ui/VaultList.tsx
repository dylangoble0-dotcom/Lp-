import { useEffect, useState } from "react";
import axios from "axios";

export function VaultList() {
  const [vaults, setVaults] = useState([]);

  useEffect(() => {
    axios.get("/api/vaults/list").then(r => setVaults(r.data));
  }, []);

  return (
    <section>
      <h2>Your Vaults</h2>
      <ul>
        {vaults.map((v: any) => (
          <li key={v.id}>
            {v.id} — {v.chain} — {v.status}
          </li>
        ))}
      </ul>
    </section>
  );
}
