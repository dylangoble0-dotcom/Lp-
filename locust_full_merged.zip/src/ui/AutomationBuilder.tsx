import React, { useState } from 'react';
import axios from 'axios';
export default function AutomationBuilder() {
  const [ruleName, setRuleName] = useState('');
  const [ruleType, setRuleType] = useState('threshold');
  const [threshold, setThreshold] = useState('100');
  const [cron, setCron] = useState('0 0 * * *');
  const [loading, setLoading] = useState(false);
  async function submit() {
    setLoading(true);
    try {
      const res = await axios.post('/api/automation/create', { ruleName, ruleType, threshold, cron });
      alert('Automation created: ' + JSON.stringify(res.data));
    } catch (err) { alert('Error ' + String(err)); } finally { setLoading(false); }
  }
  return (
    <div className="card">
      <h3 className="text-lg font-medium">Automation Builder</h3>
      <label className="block mt-2">Rule Name</label>
      <input className="w-full p-2 border rounded" value={ruleName} onChange={e=>setRuleName(e.target.value)} />
      <label className="block mt-2">Rule Type</label>
      <select className="w-full p-2 border rounded" value={ruleType} onChange={e=>setRuleType(e.target.value)}>
        <option value="threshold">Threshold</option>
        <option value="cron">Cron</option>
        <option value="price">Price</option>
      </select>
      {ruleType === 'threshold' && <>
        <label className="block mt-2">Threshold USD</label>
        <input className="w-full p-2 border rounded" value={threshold} onChange={e=>setThreshold(e.target.value)} />
      </>}
      {ruleType === 'cron' && <>
        <label className="block mt-2">Cron Expression</label>
        <input className="w-full p-2 border rounded" value={cron} onChange={e=>setCron(e.target.value)} />
      </>}
      <div className="mt-4"><button className="button" onClick={submit} disabled={loading}>{loading ? 'Creating...' : 'Create Rule'}</button></div>
    </div>
  );
}
