import React, { useState } from 'react';
import axios from 'axios';
export default function BondingBuilder() {
  const [token, setToken] = useState('');
  const [discount, setDiscount] = useState('10');
  const [vestingDays, setVestingDays] = useState('30');
  const [loading, setLoading] = useState(false);
  async function submit() {
    setLoading(true);
    try {
      const res = await axios.post('/api/bonding/create', { token, discount, vestingDays });
      alert('Bonding created: ' + JSON.stringify(res.data));
    } catch (err) { alert('Error ' + String(err)); } finally { setLoading(false); }
  }
  return (
    <div className="card"><h3 className="text-lg font-medium">Bonding Curve</h3>
    <label className="block mt-2">Token</label>
    <input className="w-full p-2 border rounded" value={token} onChange={e=>setToken(e.target.value)} />
    <label className="block mt-2">Discount (%)</label>
    <input className="w-full p-2 border rounded" value={discount} onChange={e=>setDiscount(e.target.value)} />
    <label className="block mt-2">Vesting Days</label>
    <input className="w-full p-2 border rounded" value={vestingDays} onChange={e=>setVestingDays(e.target.value)} />
    <div className="mt-4"><button className="button" onClick={submit} disabled={loading}>{loading ? 'Creating...' : 'Create Bond'}</button></div>
    </div>
  );
}
