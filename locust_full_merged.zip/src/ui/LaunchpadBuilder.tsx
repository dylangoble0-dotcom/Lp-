import React, { useState } from 'react';
import axios from 'axios';

export default function LaunchpadBuilder() {
  const [token, setToken] = useState('');
  const [type, setType] = useState('lbp');
  const [params, setParams] = useState({ startPrice: '', endPrice: '', duration: '3600' });
  const [loading, setLoading] = useState(false);

  async function submit() {
    setLoading(true);
    try {
      const res = await axios.post('/api/launchpad/create', { token, type, params });
      alert('Launch created: ' + JSON.stringify(res.data));
    } catch (err) {
      alert('Error: ' + String(err));
    } finally { setLoading(false); }
  }

  return (
    <div className="card">
      <h3 className="text-lg font-medium">Launchpad Builder</h3>
      <label className="block mt-2">Token Address</label>
      <input className="w-full p-2 border rounded" value={token} onChange={e=>setToken(e.target.value)} />
      <label className="block mt-2">Type</label>
      <select className="w-full p-2 border rounded" value={type} onChange={e=>setType(e.target.value)}>
        <option value="lbp">Liquidity Bootstrapping Pool (LBP)</option>
        <option value="bond">Bonding Curve</option>
      </select>
      <label className="block mt-2">Start Price</label>
      <input className="w-full p-2 border rounded" value={params.startPrice} onChange={e=>setParams({...params, startPrice: e.target.value})} />
      <label className="block mt-2">End Price</label>
      <input className="w-full p-2 border rounded" value={params.endPrice} onChange={e=>setParams({...params, endPrice: e.target.value})} />
      <label className="block mt-2">Duration (seconds)</label>
      <input className="w-full p-2 border rounded" value={params.duration} onChange={e=>setParams({...params, duration: e.target.value})} />
      <div className="mt-4">
        <button className="button" onClick={submit} disabled={loading}>{loading ? 'Creating...' : 'Create Launch'}</button>
      </div>
    </div>
);
}
