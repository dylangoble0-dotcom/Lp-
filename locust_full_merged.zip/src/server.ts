import express from "express";
import cors from "cors";
import { json } from "body-parser";
import { env } from "./utils/env";
import { logger } from "./utils/logger";
import vaultsRouter from "./api/routes/vaults.router";
import paymentsRouter from "./api/routes/payments.router";
import { initQueues } from "./workers/queue";

const app = express();
app.use(cors());
app.use(json());

app.use("/api/v1/vaults", vaultsRouter);
app.use("/api/v1/payments", paymentsRouter);

const port = parseInt(env.PORT || "4000", 10);
initQueues()
  .then(() => {
    app.listen(port, () => {
      logger.info(`Locust backend listening on ${port}`);
    });
  })
  .catch((err) => {
    logger.error("Failed to init queues", err);
    process.exit(1);
  });
