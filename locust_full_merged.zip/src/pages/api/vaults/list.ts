export default async function handler(req, res) {
  const r = await fetch("http://localhost:4000/api/v1/vaults/all");
  const data = await r.json();
  res.status(200).json(data);
}
