import { VaultList } from "../ui/VaultList";

export default function Home() {
  return (
    <main style={{ padding: 40 }}>
      <h1>Locust Protocol Dashboard</h1>
      <VaultList />
    </main>
  );
}
