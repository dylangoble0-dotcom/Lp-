import { useState } from 'react';
import axios from 'axios';
import { useAccount } from 'wagmi';

export default function CreateVault() {
  const { address } = useAccount();
  const [chain, setChain] = useState('ethereum');
  const [tokenMint, setTokenMint] = useState('');
  const [threshold, setThreshold] = useState('100');
  const [loading, setLoading] = useState(false);

  async function submit() {
    setLoading(true);
    try {
      const res = await axios.post('/api/create-vault', {
        ownerWallet: address,
        chain,
        address: 'placeholder-vault-address',
        tokenMint,
        thresholdUsd: threshold
      });
      alert('Vault created: ' + JSON.stringify(res.data));
    } catch (err) {
      alert('error ' + String(err));
    } finally { setLoading(false); }
  }

  return (
    <div className='container'>
      <h1 className='text-2xl font-bold mb-4'>Create Treasury Vault</h1>
      <div className='card'>
        <label className='block mb-2'>Chain</label>
        <select value={chain} onChange={e=>setChain(e.target.value)} className='w-full p-2 border rounded mb-3'>
          <option value='ethereum'>Ethereum</option>
          <option value='polygon'>Polygon</option>
          <option value='solana'>Solana</option>
        </select>
        <label className='block mb-2'>Token Mint (optional)</label>
        <input className='w-full p-2 border rounded mb-3' value={tokenMint} onChange={e=>setTokenMint(e.target.value)} />
        <label className='block mb-2'>Threshold USD</label>
        <input className='w-full p-2 border rounded mb-3' value={threshold} onChange={e=>setThreshold(e.target.value)} />
        <button className='button' onClick={submit} disabled={loading}>{loading ? 'Creating...' : 'Create Vault'}</button>
      </div>
    </div>
  );
}
