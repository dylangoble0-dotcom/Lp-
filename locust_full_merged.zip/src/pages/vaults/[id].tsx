import { useRouter } from "next/router";
import { useEffect, useState } from "react";
import axios from "axios";

export default function VaultPage() {
  const router = useRouter();
  const { id } = router.query;
  const [vault, setVault] = useState(null);

  useEffect(() => {
    if (!id) return;
    axios.get(`/api/vaults/${id}`).then(r => setVault(r.data));
  }, [id]);

  return (
    <main style={{ padding: 40 }}>
      <h1>Vault Details</h1>
      {vault ? <pre>{JSON.stringify(vault, null, 2)}</pre> : "Loading..."}
    </main>
  );
}
