export default function Launchpad() {
  return (
    <div className='container'>
      <h1 className='text-2xl font-bold mb-4'>Launchpad</h1>
      <div className='card'>
        <p>Launchpad tools: LBP, bonding, initial LP creation, OpenBook and Raydium integrations (UI coming soon).</p>
      </div>
    </div>
  );
}
