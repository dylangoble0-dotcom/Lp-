import { useState } from 'react';
import axios from 'axios';
import { useAccount } from 'wagmi';

export default function CreateToken() {
  const { address } = useAccount();
  const [name, setName] = useState('');
  const [symbol, setSymbol] = useState('');
  const [supply, setSupply] = useState('1000000');
  const [chain, setChain] = useState('ethereum');
  const [loading, setLoading] = useState(false);

  async function submit() {
    setLoading(true);
    try {
      const res = await axios.post('/api/create-token', {
        ownerWallet: address,
        name, symbol, supply, chain
      });
      alert('Token created (demo): ' + JSON.stringify(res.data));
    } catch (err) {
      alert('Error creating token: ' + String(err));
    } finally { setLoading(false); }
  }

  return (
    <div className='container'>
      <h1 className='text-2xl font-bold mb-4'>Create Token</h1>
      <div className='card'>
        <label className='block mb-2'>Name</label>
        <input className='w-full p-2 border rounded mb-3' value={name} onChange={e=>setName(e.target.value)} />
        <label className='block mb-2'>Symbol</label>
        <input className='w-full p-2 border rounded mb-3' value={symbol} onChange={e=>setSymbol(e.target.value)} />
        <label className='block mb-2'>Supply</label>
        <input className='w-full p-2 border rounded mb-3' value={supply} onChange={e=>setSupply(e.target.value)} />
        <label className='block mb-2'>Chain</label>
        <select value={chain} onChange={e=>setChain(e.target.value)} className='w-full p-2 border rounded mb-3'>
          <option value='ethereum'>Ethereum</option>
          <option value='polygon'>Polygon</option>
          <option value='solana'>Solana</option>
        </select>
        <button className='button' onClick={submit} disabled={loading}>{loading ? 'Creating...' : 'Create Token'}</button>
      </div>
    </div>
  );
}
