import { useEffect, useState } from 'react';
import axios from 'axios';

export default function LpMonitor() {
  const [positions, setPositions] = useState([]);
  useEffect(() => {
    axios.get('/api/lp/positions').then(r=>setPositions(r.data)).catch(()=>setPositions([]));
  }, []);
  return (
    <div className='container'>
      <h1 className='text-2xl font-bold mb-4'>LP Monitor</h1>
      <div className='card'>
        <ul>
          {positions.map((p:any)=>(
            <li key={p.id}>{p.lp} — {p.owner} — {p.tvl}</li>
          ))}
        </ul>
      </div>
    </div>
  );
}
