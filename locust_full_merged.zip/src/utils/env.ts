import dotenv from "dotenv";
dotenv.config();

export const env = {
  PORT: process.env.PORT || "4000",
  DATABASE_URL: process.env.DATABASE_URL || "",
  REDIS_URL: process.env.REDIS_URL || "redis://127.0.0.1:6379",
  ETH_RPC: process.env.ETH_RPC || "",
  SOLANA_RPC: process.env.SOLANA_RPC || "",
  PRIVATE_KEY_RELAYER: process.env.PRIVATE_KEY_RELAYER || "",
  ONEINCH_API: process.env.ONEINCH_API || "",
  JUPITER_API: process.env.JUPITER_API || "",
  ADMIN_USDC_ADDRESS: process.env.ADMIN_USDC_ADDRESS || ""
};
