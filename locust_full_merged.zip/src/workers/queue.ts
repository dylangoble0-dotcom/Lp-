import { Queue, Worker, QueueScheduler } from "bullmq";
import IORedis from "ioredis";
import { env } from "../utils/env";
import { processPaymentJob } from "../services/payments/paymentProcessor";
import { logger } from "../utils/logger";

const connection = new IORedis(env.REDIS_URL);

export const paymentQueue = new Queue("payments", { connection });
export const paymentQueueScheduler = new QueueScheduler("payments", { connection });

export async function initQueues() {
  new Worker("payments", async job => {
    logger.info("Processing payment job", job.id, job.name);
    if (job.name === "processPayment") {
      await processPaymentJob(job.data.paymentId);
    }
  }, { connection });

  return;
}

export async function enqueuePaymentProcessing(paymentId: string) {
  await paymentQueue.add("processPayment", { paymentId }, { attempts: 5, backoff: { type: "exponential", delay: 2000 } });
}
