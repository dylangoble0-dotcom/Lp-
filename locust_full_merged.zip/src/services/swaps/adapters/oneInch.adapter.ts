import axios from "axios";
import { env } from "../../../utils/env";
import { logger } from "../../../utils/logger";

const ONEINCH_BASE = env.ONEINCH_API || "https://api.1inch.io/v5.0";

export default {
  async swapToUsdc({ chain, fromAsset, amount, toAddress }: any) {
    const chainId = chain === "ethereum" ? 1 : (chain === "polygon" ? 137 : 1);
    logger.info("1inch swapToUsdc", { chainId, fromAsset, amount, toAddress });
    // production: build quote & tx, sign with relayer key, send tx
    return { success: true, txHash: null, raw: {} };
  }
};
