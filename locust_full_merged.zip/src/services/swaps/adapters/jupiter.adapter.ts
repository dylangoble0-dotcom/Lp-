import axios from "axios";
import { env } from "../../../utils/env";
import { logger } from "../../../utils/logger";

const JUPITER_API = env.JUPITER_API || "https://quote-api.jup.ag";

export default {
  async swapToUsdc({ chain, fromAsset, amount, toAddress }: any) {
    logger.info("jupiter swapToUsdc", { fromAsset, amount, toAddress });
    // production: call jupiter quote endpoints and build transaction instructions
    return { success: true, txHash: null, raw: {} };
  }
};
