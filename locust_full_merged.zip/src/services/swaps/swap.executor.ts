import { env } from "../../utils/env";
import { logger } from "../../utils/logger";
import OneInchAdapter from "./adapters/oneInch.adapter";
import JupiterAdapter from "./adapters/jupiter.adapter";

type SwapRequest = {
  chain: string;
  fromAsset: string;
  amount: string;
  toAddress: string;
};

export class SwapExecutor {
  static async swapToUsdc(req: SwapRequest) {
    logger.info("swapToUsdc", req);
    if (req.chain === "solana") {
      const res = await JupiterAdapter.swapToUsdc(req);
      return res;
    } else {
      const res = await OneInchAdapter.swapToUsdc(req);
      return res;
    }
  }
}
