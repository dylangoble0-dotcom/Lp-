import { logger } from '../../utils/logger';
export async function startIndexer() {
  logger.info("Indexer starting...");
  // production: spawn chain-specific indexers
}
