import { ethers } from "ethers";
import { prisma } from "../../db/prismaClient";
import { logger } from "../../utils/logger";

export async function indexPair(pairAddress: string) {
  logger.info("Indexing pair", pairAddress);
  // production: use ABI to read getReserves and totalSupply, persist to DB
}
