import { prisma } from "../../db/prismaClient";
import { logger } from "../../utils/logger";
import { SwapExecutor } from "../swaps/swap.executor";

export async function processPaymentJob(paymentId: string) {
  const payment = await prisma.payment.findUnique({ where: { id: paymentId }});
  if (!payment) throw new Error("payment not found");
  if (payment.processed) return;

  logger.info("Processing payment", payment);

  await prisma.payment.update({ where: { id: paymentId }, data: { processed: true }});

  const asset = payment.asset.toLowerCase();
  if (asset !== "usdc" && asset !== "usdt") {
    const swapResult = await SwapExecutor.swapToUsdc({
      chain: payment.chain,
      fromAsset: payment.asset,
      amount: payment.amount.toString(),
      toAddress: process.env.ADMIN_USDC_ADDRESS || ""
    });
    await prisma.operation.create({
      data: {
        vaultId: null,
        type: "SWAP",
        asset: payment.asset,
        amount: payment.amount,
        txHash: swapResult.txHash || null,
        status: "DONE"
      }
    });
  } else {
    await prisma.operation.create({
      data: {
        vaultId: null,
        type: "RECEIVE",
        asset: payment.asset,
        amount: payment.amount,
        txHash: payment.txHash,
        status: "DONE"
      }
    });
  }

  logger.info("Payment processed", paymentId);
}
