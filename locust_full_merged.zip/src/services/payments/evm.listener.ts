import { ethers } from "ethers";
import { env } from "../../utils/env";
import { prisma } from "../../db/prismaClient";
import { logger } from "../../utils/logger";

const provider = new ethers.JsonRpcProvider(env.ETH_RPC);

export async function watchEvmAddress(address: string) {
  provider.on("pending", async (txHash: any) => {
    try {
      const tx = await provider.getTransaction(txHash);
      if (!tx) return;
      if (tx.to && tx.to.toLowerCase() === address.toLowerCase()) {
        logger.info("incoming evm tx", txHash);
        await prisma.payment.create({
          data: {
            txHash: txHash,
            chain: "ethereum",
            asset: "UNKNOWN",
            amount: 0,
            from: tx.from || "",
            to: tx.to || ""
          }
        });
      }
    } catch (err) {
      logger.error("watchEvmAddress error", err);
    }
  });
}
