import { Connection, PublicKey } from "@solana/web3.js";
import { env } from "../../utils/env";
import { prisma } from "../../db/prismaClient";
import { logger } from "../../utils/logger";

const conn = new Connection(env.SOLANA_RPC || "https://api.mainnet-beta.solana.com");

export function watchSolanaAddress(pubkey: string) {
  conn.onLogs(new PublicKey(pubkey), (logs, ctx) => {
    logger.info("sol logs", logs);
    // production: decode transaction and detect SPL transfers
  });
}
