import Layout from '../components/Layout';
import MetricBlock from '../components/MetricBlock';
export default function Home() {
  return (
    <Layout active='dashboard'>
      <div style={{display:'grid', gridTemplateColumns:'1fr 320px', gap:20}}>
        <div className='pf-panel pf-card'>
          <h2 style={{fontSize:20, marginBottom:6}}>Overview</h2>
          <p style={{color:'var(--muted)'}}>System health and treasury metrics</p>
          <div style={{display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:12, marginTop:12}}>
            <MetricBlock label='Total Treasury (USDC)' value='$12,420' />
            <MetricBlock label='Active Vaults' value='14' />
            <MetricBlock label='Pending Swaps' value='2' />
          </div>
        </div>
        <div className='pf-panel pf-card'>
          <h3 style={{fontSize:16}}>Quick Status</h3>
          <div style={{marginTop:10, display:'flex', flexDirection:'column', gap:8}}>
            <div style={{display:'flex', justifyContent:'space-between'}}><div style={{color:'var(--muted)'}}>Relayer</div><div style={{color:'var(--accent)'}}>Online</div></div>
            <div style={{display:'flex', justifyContent:'space-between'}}><div style={{color:'var(--muted)'}}>KMS</div><div style={{color:'var(--accent)'}}>Configured</div></div>
            <div style={{display:'flex', justifyContent:'space-between'}}><div style={{color:'var(--muted)'}}>Swaps Today</div><div style={{color:'var(--muted)'}}>23</div></div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
