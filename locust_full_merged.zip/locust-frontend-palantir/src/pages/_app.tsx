import '../styles/globals.css';
import '../styles/theme.css';
import type { AppProps } from 'next/app';
import { WagmiConfig, createClient, configureChains, mainnet, goerli } from 'wagmi';
import { publicProvider } from 'wagmi/providers/public';
import { RainbowKitProvider, getDefaultWallets } from '@rainbow-me/rainbowkit';
import '@rainbow-me/rainbowkit/styles.css';
import { SolanaWalletProvider } from '../wallets/solanaProvider';

const { chains, provider } = configureChains(
  [mainnet, goerli],
  [publicProvider()]
);

const { connectors } = getDefaultWallets({
  appName: 'Locust Protocol',
  chains
});

const wagmiClient = createClient({
  autoConnect: true,
  connectors,
  provider
});

export default function App({ Component, pageProps }: AppProps) {
  return (
    <WagmiConfig client={wagmiClient}>
      <RainbowKitProvider chains={chains}>
        <SolanaWalletProvider>
          <Component {...pageProps} />
        </SolanaWalletProvider>
      </RainbowKitProvider>
    </WagmiConfig>
  );
}
