import { test, expect } from '@playwright/test';

test('homepage loads and shows dashboard', async ({ page }) => {
  await page.goto('http://localhost:3000');
  await expect(page.locator('text=Locust Protocol')).toBeVisible();
});

test('create token form visible', async ({ page }) => {
  await page.goto('http://localhost:3000/create-token');
  await expect(page.locator('text=Create Token')).toBeVisible();
});
