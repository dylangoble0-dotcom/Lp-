import Head from 'next/head';
import Link from 'next/link';
import { ConnectButton } from '@rainbow-me/rainbowkit';
import { WalletMultiButton } from '@solana/wallet-adapter-react-ui';
import { VaultList } from '../ui/VaultList';
import LaunchpadBuilder from '../ui/LaunchpadBuilder';
import BondingBuilder from '../ui/BondingBuilder';
import VestingBuilder from '../ui/VestingBuilder';
import AutomationBuilder from '../ui/AutomationBuilder';

export default function Home() {
  return (
    <div className='container'>
      <Head><title>Locust Protocol</title></Head>
      <header className='header'>
        <h1 className='text-2xl font-bold'>Locust Protocol</h1>
        <div className='flex gap-4'>
          <ConnectButton />
          <WalletMultiButton />
        </div>
      </header>

      <main className='grid grid-cols-3 gap-6'>
        <section className='col-span-2'>
          <div className='card'>
            <h2 className='text-xl font-semibold'>Dashboard</h2>
            <div className='grid grid-cols-2 gap-4 mt-4'>
              <LaunchpadBuilder />
              <BondingBuilder />
            </div>
            <p className='text-sm text-gray-600'>Manage your vaults, token launches, and automations.</p>
            <div style={{ marginTop: 16 }}>
              <Link href='/create-token'><a className='button'>Create Token</a></Link>
              <Link href='/create-vault'><a className='ml-4 button'>Create Vault</a></Link>
            </div>
          </div>

          <div className='card mt-6'>
            <h3 className='text-lg font-medium mb-2'>Your Vaults</h3>
            <VaultList />
          </div>
        </section>

        <aside>
          <div className='card'>
            <h3 className='text-lg font-medium'>Quick Actions</h3>
            <ul className='mt-3'>
              <li className='py-2'><Link href='/launchpad'><a className='text-blue-600'>Token Launchpad</a></Link></li>
              <li className='py-2'><Link href='/lp-monitor'><a className='text-blue-600'>LP Monitor</a></Link></li>
              <li className='py-2'><Link href='/analytics'><a className='text-blue-600'>Analytics</a></Link></li>
            </ul>
          </div>
        </aside>
      </main>
    </div>
  );
}


<div className='card mt-6'><h3 className='text-lg font-medium'>Automation</h3><AutomationBuilder /></div>