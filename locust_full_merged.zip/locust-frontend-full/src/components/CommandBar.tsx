export default function CommandBar({ children }: { children?: any }) {
  return (
    <div className='pf-header'>
      <div style={{display:'flex', gap:12, alignItems:'center'}}>
        <div className='pf-command' style={{fontWeight:700}}>Locust Protocol — Operator Console</div>
        <div style={{color:'var(--muted)', fontSize:13}}>Connected: <span style={{color:'var(--accent)'}}>Mainnet</span></div>
      </div>
      <div style={{display:'flex', gap:8}}>
        {children}
      </div>
    </div>
  );
}
