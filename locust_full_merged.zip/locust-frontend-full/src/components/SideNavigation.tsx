import Link from 'next/link';
export default function SideNavigation({ active='dashboard' }: { active?: string }) {
  const items = [
    { key: 'dashboard', label: 'Dashboard', href: '/' },
    { key: 'tokens', label: 'Tokens', href: '/tokens' },
    { key: 'vaults', label: 'Vaults', href: '/vaults' },
    { key: 'automation', label: 'Automation', href: '/automation' },
    { key: 'launchpad', label: 'Launchpad', href: '/launchpad' },
    { key: 'admin', label: 'Admin', href: '/admin' }
  ];
  return (
    <aside className='pf-side'>
      <div className='logo'>LOCUST OS</div>
      <nav>
        {items.map(i=>(
          <Link key={i.key} href={i.href}><a className={i.key===active ? 'active' : ''}>{i.label}</a></Link>
        ))}
      </nav>
    </aside>
  );
}
