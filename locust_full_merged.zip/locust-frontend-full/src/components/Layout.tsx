import SideNavigation from './SideNavigation';
import CommandBar from './CommandBar';
export default function Layout({ children, active }: { children:any, active?:string }) {
  return (
    <div>
      <SideNavigation active={active} />
      <div className='pf-main'>
        <CommandBar>
          <div style={{display:'flex', gap:8}}>
            <button className='pf-button'>Create Token</button>
          </div>
        </CommandBar>
        <main style={{marginTop:14}}>
          {children}
        </main>
      </div>
    </div>
  );
}
