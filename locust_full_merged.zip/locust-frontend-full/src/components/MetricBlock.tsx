export default function MetricBlock({ label, value }: { label:string, value: string }) {
  return (
    <div className='metric'>
      <div className='value'>{value}</div>
      <div className='label'>{label}</div>
    </div>
  );
}
