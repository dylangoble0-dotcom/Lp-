import { useEffect, useState } from 'react';
import axios from 'axios';
import Link from 'next/link';

export function VaultList() {
  const [vaults, setVaults] = useState<any[]>([]);
  useEffect(() => {
    axios.get('/api/vaults/list').then(r => setVaults(r.data)).catch(()=>setVaults([]));
  }, []);

  return (
    <section>
      <ul>
        {vaults.map((v) => (
          <li key={v.id} className='p-3 border-b'>
            <Link href={`/vaults/${v.id}`}>
              <a className='block'>
                <div className='flex justify-between'>
                  <div>
                    <div className='font-medium'>{v.id}</div>
                    <div className='text-sm text-gray-500'>{v.chain}</div>
                  </div>
                  <div className='text-sm'>{v.status}</div>
                </div>
              </a>
            </Link>
          </li>
        ))}
      </ul>
    </section>
  );
}
