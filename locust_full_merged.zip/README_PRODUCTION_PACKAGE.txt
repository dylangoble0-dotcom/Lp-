
LOCUST PRODUCTION-READY PACKAGE
--------------------------------
This archive contains the assembled production-ready code for Locust Protocol (backend + frontend + infra skeleton + relayer/signers + swap adapters).
IMPORTANT:
- Do NOT run on mainnet until audited.
- Replace all placeholder env variables before deploying.
- Use AWS KMS or Hardware signer for relayer; do not store private keys in repo.
- Follow the READMEs in each subfolder for detailed deploy steps.

Folders included (if present):
- locust-backend-full
- locust-frontend-full
- locust-frontend-palantir
- locust-repo-scaffold
- additional zips expanded

Next steps:
1) Edit backend/.env using .env.example
2) Provision Postgres & Redis (docker-compose provided)
3) Create KMS key and map KMS_KEY_ID into env/secrets
4) Run prisma migrate, start backend & worker, then frontend
5) Test on Sepolia / Solana devnet

If you want, I can produce a signed checklist script to automate many of these steps.
